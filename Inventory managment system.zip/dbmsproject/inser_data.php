<?php
include('dbcon.php');

if (isset($_POST['add_products'])) {
    $productname = $_POST['p_name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price']; 
    $date = $_POST['Date'];

    if (empty($productname)) {
        header('location:index.php?message=You need to fill the product name!');
        exit();
    }

    if (empty($quantity)) {
        header('location:index.php?message=You need to fill the quantity!');
        exit();
    }

    if (empty($price)) {
        header('location:index.php?message=You need to fill the price!');
        exit();
    }

    if (empty($date)) {
        header('location:index.php?message=You need to enter the date!');
        exit();
    }

    $query = "INSERT INTO `products` (`Product Name`, `quantity`, `price`, `Arrived date`) 
              VALUES ('$productname', '$quantity', '$price', '$date')";

    $result = mysqli_query($connection, $query);

    if (!$result) {
        die("Query Failed: " . mysqli_error($connection));
    } else {
        header('location:index.php?insert_msg=Your data has been added successfully');
        exit();
    }
}
?>
