document.addEventListener("DOMContentLoaded", function () {
    const productIdInput = document.querySelector('[name="product_id"]');
    const quantityInput = document.querySelector('[name="quantity"]');
    const priceInput = document.getElementById("price");
    const totalPriceInput = document.getElementById("total_price");

    // Fetch price when the product ID is entered
    productIdInput.addEventListener("input", async function () {
        const productId = this.value;

        if (productId) {
            try {
                const response = await fetch(`fetch_price.php?id=${productId}`);
                const data = await response.json();

                if (data.price > 0) {
                    priceInput.value = data.price;
                    calculateTotalPrice();
                } else {
                    priceInput.value = 'N/A';
                    totalPriceInput.value = '';
                    alert('Product not found or price not set');
                }
            } catch (error) {
                console.error("Error fetching product price:", error);
            }
        } else {
            priceInput.value = '';
            totalPriceInput.value = '';
        }
    });

    // Calculate total price when quantity is entered
    quantityInput.addEventListener("input", calculateTotalPrice);

    function calculateTotalPrice() {
        const quantity = parseFloat(quantityInput.value);
        const price = parseFloat(priceInput.value);

        if (quantity > 0 && price > 0) {
            totalPriceInput.value = (price * quantity).toFixed(2);
        } else {
            totalPriceInput.value = '';
        }
    }
});
