<?php include('header.php'); ?>
<?php include('dbcon.php'); ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-3" style="padding: 10px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5); border-bottom: 3px solid #007bff;">
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item" style="margin-right: 20px;">
                <a class="nav-link" href="index.php?add_product=1" style="font-size: 16px; font-weight: bold; color: #ffffff; transition: color 0.3s;">
                    Add and View Product
                </a>
            </li>
            <li class="nav-item" style="margin-right: 20px;">
                <a class="nav-link" href="sales.php" style="font-size: 16px; font-weight: bold; color: #ffffff; transition: color 0.3s;">
                    Sales
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php" style="font-size: 16px; font-weight: bold; color: #ffffff; transition: color 0.3s;">
                    Home
                </a>
            </li>
        </ul>
    </div>
</nav>

<div class="box1">
    <h2>All Stocks</h2>
    <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Add Products</button>
</div>

<table class="table table-hover table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th> 
            <th>Arrived Date</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $query = "SELECT * FROM `products`";
        $result = mysqli_query($connection, $query);

        if (!$result) {
            die("Query Failed: " . mysqli_error($connection));
        } else {
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <tr>
                    <td><?php echo $row['ID']; ?></td>
                    <td><?php echo $row['Product Name']; ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td><?php echo $row['price']; ?></td> 
                    <td><?php echo $row['Arrived date']; ?></td>
                    <td><a href="update.php?id=<?php echo $row['ID']; ?>" class="btn btn-success">Update</a></td>
                    <td><a href="delete.php?id=<?php echo $row['ID']; ?>" class="btn btn-danger">Delete</a></td>
                </tr>
                <?php
            }
        }
        ?>
    </tbody>
</table>


<?php
if (isset($_GET['message'])) {
    echo "<h6>" . htmlspecialchars($_GET['message']) . "</h6>";
}

if (isset($_GET['insert_msg'])) {
    echo "<h6 class='success-message'>" . htmlspecialchars($_GET['insert_msg']) . "</h6>";
}

if (isset($_GET['update_msg'])) {
    echo "<h6 class='success-message'>" . htmlspecialchars($_GET['update_msg']) . "</h6>";
}

if (isset($_GET['delete_msg'])) {
    echo "<h6 class='success-message'>" . htmlspecialchars($_GET['delete_msg']) . "</h6>";
}
?>

<form action="inser_data.php" method="post">
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Add Product</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="p_name">Product Name</label>
                        <input type="text" name="p_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" name="quantity" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="price">Price</label> <!-- New Price Field -->
                        <input type="number" name="price" step="0.01" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Date">Arrived Date</label>
                        <input type="date" name="Date" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-success" name="add_products" value="ADD">
                </div>
            </div>
        </div>
    </div>
</form>

<?php include('footer.php'); ?>
