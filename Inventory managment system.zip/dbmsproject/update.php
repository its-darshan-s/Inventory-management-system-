<?php include('header.php'); ?>
<?php include('dbcon.php'); ?>

<?php

if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    $query = "SELECT * FROM `products` WHERE `id` = '$id'";
    $result = mysqli_query($connection, $query);

    if(!$result) {
        die("Query Failed: " . mysqli_error($connection)); 
    } else {
        $row = mysqli_fetch_assoc($result);
    }
} else {
    echo "Invalid product ID.";
    exit(); 
}
?>

<?php

if(isset($_POST['update_products'])){

    $p_name = $_POST['p_name'];
    $quantity = $_POST['quantity'];
    $Date = $_POST['Date'];

    $query = "UPDATE `products` 
              SET `Product Name` = '$p_name', `quantity` = '$quantity', `Arrived date` = '$Date' 
              WHERE `id` = $id";

    $result = mysqli_query($connection, $query);

    if(!$result) {
        die("Query Failed: " . mysqli_error($connection)); 
    } else {
        header('location:index.php?update_msg=You have updated the data successfully');
        exit();
    }
}
?>

<form action="update.php?id=<?php echo $id; ?>" method="post">
    <div class="form-group">
        <label for="p_name">Product Name</label>
        <input type="text" name="p_name" class="form-control" value="<?php echo $row['Product Name']; ?>" required>
    </div>
    <div class="form-group">
        <label for="quantity">Quantity</label>
        <input type="text" name="quantity" class="form-control" value="<?php echo $row['quantity']; ?>" required>
    </div>
    <div class="form-group">
        <label for="Date">Date</label>
        <input type="date" name="Date" class="form-control" value="<?php echo $row['Arrived date']; ?>" required> 
    </div>
    <input type="submit" class="btn btn-success" name="update_products" value="UPDATE">
</form>

<?php include('footer.php'); ?>
