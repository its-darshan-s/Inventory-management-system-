<?php
include('dbcon.php');
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    $query = "SELECT price FROM products WHERE ID = '$product_id'";
    $result = mysqli_query($connection, $query);
    if ($result) {
        $product = mysqli_fetch_assoc($result);
        echo json_encode(['price' => $product['price']]);
    } else {
        echo json_encode(['price' => 0]);
    }
}
?>
