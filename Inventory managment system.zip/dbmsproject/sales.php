<?php include('header.php'); ?>
<?php include('dbcon.php'); ?>


<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-3" style="padding: 10px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5); border-bottom: 3px solid #007bff;">
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item" style="margin-right: 20px;">
                <a class="nav-link" href="index.php?add_product=1" style="font-size: 16px; font-weight: bold; color: #ffffff; transition: color 0.3s;">
                    Add and View Product
                </a>
            </li>
            <li class="nav-item" style="margin-right: 20px;">
                <a class="nav-link" href="sales.php" style="font-size: 16px; font-weight: bold; color: #ffffff; transition: color 0.3s;">
                    Sales
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php" style="font-size: 16px; font-weight: bold; color: #ffffff; transition: color 0.3s;">
                    Home
                </a>
            </li>
        </ul>
    </div>
</nav>


<h2>Sales Management</h2>

<form method="POST" class="mb-4">
    <div class="form-group">
        <label for="product_id">Product ID:</label>
        <input type="number" name="product_id" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="customer_name">Customer Name:</label> 
        <input type="text" name="customer_name" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="quantity">Quantity:</label>
        <input type="number" name="quantity" class="form-control" min="1" required>
    </div>
    <div class="form-group">
        <label for="price">Price per Item:</label> 
        <input type="text" id="price" class="form-control" readonly>
    </div>
    <div class="form-group">
        <label for="total_price">Total Price:</label> 
        <input type="text" id="total_price" class="form-control" readonly>
    </div>
    <button type="submit" class="btn btn-primary">Record Sale</button>
</form>

<h3>Sales Records</h3>
<table class="table table-hover table-bordered table-striped">
    <thead>
        <tr>
            <th>Sale ID</th>
            <th>Product ID</th>
            <th>Customer Name</th> 
            <th>Quantity</th>
            <th>Total Price</th> 
            <th>Sale Date</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sales_query = "SELECT * FROM sales";
        $sales_result = mysqli_query($connection, $sales_query);

        if ($sales_result) {
            while ($row = mysqli_fetch_assoc($sales_result)) {
                echo "<tr>
                        <td>{$row['sale_id']}</td>
                        <td>{$row['product_id']}</td>
                        <td>{$row['customer_name']}</td>
                        <td>{$row['quantity']}</td>
                        <td>{$row['total_price']}</td>
                        <td>{$row['sale_date']}</td>
                        <td>
                            <form method='POST' action='sales.php' style='display:inline;'>
                                <input type='hidden' name='delete_sale_id' value='{$row['sale_id']}'>
                                <button type='submit' class='btn btn-danger btn-sm' onclick=\"return confirm('Are you sure you want to delete this sale?');\">Delete</button>
                            </form>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='7' class='text-center'>No sales records found.</td></tr>";
        }
        ?>
    </tbody>
</table>

<?php
// Initialize variables for the receipt
$ID = $customer_name = $quantity = $price_per_item = $total_price = null;

if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

if (isset($_POST['delete_sale_id'])) {
    $sale_id = filter_var($_POST['delete_sale_id'], FILTER_SANITIZE_NUMBER_INT);

    $delete_sale_query = "DELETE FROM sales WHERE sale_id = '$sale_id'";
    if (mysqli_query($connection, $delete_sale_query)) {
        echo "<div class='alert alert-success'>Sale record deleted successfully!</div>";
        echo "<meta http-equiv='refresh' content='0'>";
    } else {
        echo "<div class='alert alert-danger'>Error deleting sale record: " . mysqli_error($connection) . "</div>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['delete_sale_id'])) {
    $ID = filter_var($_POST['product_id'], FILTER_SANITIZE_NUMBER_INT);
    $customer_name = mysqli_real_escape_string($connection, $_POST['customer_name']); 
    $quantity = filter_var($_POST['quantity'], FILTER_SANITIZE_NUMBER_INT);

    if ($ID <= 0 || $quantity <= 0) {
        echo "<div class='alert alert-danger'>Invalid Product ID or Quantity.</div>";
    } else {
        $check_query = "SELECT quantity, price FROM products WHERE ID = '$ID'";
        $check_result = mysqli_query($connection, $check_query);

        if ($check_result) {
            $product = mysqli_fetch_assoc($check_result);
            if ($product && $product['quantity'] >= $quantity) {
                $price_per_item = $product['price'];
                $total_price = $price_per_item * $quantity; 

                $insert_query = "INSERT INTO sales (product_id, customer_name, quantity, total_price, sale_date) 
                                 VALUES ('$ID', '$customer_name', '$quantity', '$total_price', NOW())";
                $update_query = "UPDATE products SET quantity = quantity - '$quantity' WHERE ID = '$ID'";

                if (mysqli_query($connection, $insert_query) && mysqli_query($connection, $update_query)) {
                    echo "<div class='alert alert-success'>Sale recorded successfully!</div>";
                } else {
                    echo "<div class='alert alert-danger'>Error recording sale: " . mysqli_error($connection) . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Insufficient quantity!</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>Query failed: " . mysqli_error($connection) . "</div>";
        }
    }
}
?>

<!-- Receipt Section -->
<?php if (isset($ID, $customer_name, $quantity, $price_per_item, $total_price)): ?>
<div class="receipt">
    <h3>Receipt</h3>
    <p><strong>Product ID:</strong> <?php echo htmlspecialchars($ID); ?></p>
    <p><strong>Customer Name:</strong> <?php echo htmlspecialchars($customer_name); ?></p>
    <p><strong>Quantity:</strong> <?php echo htmlspecialchars($quantity); ?></p>
    <p><strong>Price per Item:</strong> ₹<?php echo number_format($price_per_item, 2); ?></p>
    <p><strong>Total Price:</strong> ₹<?php echo number_format($total_price, 2); ?></p>
    <button onclick="printReceipt()" class="btn btn-primary">Print Receipt</button>
</div>
<?php endif; ?>

<!-- Styling for the Receipt -->
<style>
    .receipt {
        border: 1px solid #ccc;
        padding: 15px;
        margin-top: 20px;
        width: 300px;
    }
    .receipt h3 {
        text-align: center;
        margin-bottom: 15px;
    }
    .receipt p {
        margin: 5px 0;
    }
</style>

<script src="sales.js"></script>
<script>
function printReceipt() {
    const originalContent = document.body.innerHTML;
    const receiptContent = document.querySelector('.receipt').outerHTML;

    document.body.innerHTML = receiptContent;
    window.print();
    document.body.innerHTML = originalContent;
}
</script>

<?php include('footer.php'); ?>
