<?php include('dbcon.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Products</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        .container { margin-top: 50px; background: rgba(0, 0, 0, 0.6); padding: 20px; border-radius: 8px; }
        .card { border: none; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); }
        .card-header { background-color: #007bff; color: white; font-weight: bold; border-radius: 8px 8px 0 0; }
        .logout-btn { margin-top: 20px; background-color: #dc3545; border: none; }
        .logout-btn:hover { background-color: #c82333; }
        .chart-container { width: 100%; max-width: 400px; margin: 0 auto; }
        canvas { max-height: 300px; }
    </style>
</head>
<body style="background-image: url('image1.gif'); background-size: cover; background-position: center; color: white;">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-3" style="padding: 10px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5); border-bottom: 3px solid #007bff; transition: all 0.3s;">
    <a class="navbar-brand" href="#" style="font-size: 20px; font-weight: bold; color: #ffffff; text-shadow: 0px 2px 4px rgba(0, 0, 0, 0.6); transition: transform 0.3s;">
        Inventory Dashboard
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item" style="margin-right: 20px;">
                <a class="nav-link" href="index.php?add_product=1" style="font-size: 16px; font-weight: bold; color: #ffffff; transition: color 0.3s ease-in-out;">
                    Add and View Product
                </a>
            </li>
            <li class="nav-item" style="margin-right: 20px;">
                <a class="nav-link" href="sales.php" style="font-size: 16px; font-weight: bold; color: #ffffff; transition: color 0.3s ease-in-out;">
                    Sales
                </a>
            </li>
        </ul>
        <a href="login.php" class="btn btn-danger ml-auto" style="font-size: 14px; padding: 5px 10px; border-radius: 5px; transition: background-color 0.3s ease;">
            Logout
        </a>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="text-center">Inventory Management System</h2>
    <h2 class="text-center">Admin Dashboard</h2>

    <div class="card mt-3">
        <div class="card-header">
            <h3>Products</h3>
        </div>
    </div>
</div>

<div class="container mt-3">
    <h3>Product Inventory Chart</h3>
    <div class="chart-container">
        <canvas id="productChart"></canvas>
    </div>
</div>

<div class="container mt-3">
    <h3>Sales Chart</h3>
    <div class="chart-container">
        <canvas id="salesChart"></canvas>
    </div>
</div>

<?php
    $sql = "SELECT `Product Name`, `quantity` FROM products";
    $result = $connection->query($sql);

    $product_data = [];
    while ($row = $result->fetch_assoc()) {
        $product_data[] = $row;
    }

    $sales_sql = "SELECT `product_id`, `quantity` FROM sales";
    $sales_result = $connection->query($sales_sql);

    $sales_data = [];
    while ($row = $sales_result->fetch_assoc()) {
        $sales_data[] = $row;
    }
?>

<script>
    var productData = <?php echo json_encode($product_data); ?>;
    var productLabels = productData.map(item => item['Product Name']);
    var productQuantities = productData.map(item => item['quantity']);

    var ctx1 = document.getElementById('productChart').getContext('2d');
    new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: productLabels,
            datasets: [{
                label: 'Quantity',
                data: productQuantities,
                backgroundColor: 'rgba(54, 162, 235, 0.8)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: 'rgba(255, 255, 255, 0.8)' }
                },
                x: {
                    ticks: { color: 'rgba(255, 255, 255, 0.8)' }
                }
            }
        }
    });

    var salesData = <?php echo json_encode($sales_data); ?>;
    var salesLabels = salesData.map(item => item['product_id']);
    var salesQuantities = salesData.map(item => item['quantity']);

    var ctx2 = document.getElementById('salesChart').getContext('2d');
    new Chart(ctx2, {
        type: 'pie',
        data: {
            labels: salesLabels,
            datasets: [{
                label: 'Sales Quantity',
                data: salesQuantities,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.8)',
                    'rgba(255, 159, 64, 0.8)',
                    'rgba(75, 192, 192, 0.8)',
                    'rgba(153, 102, 255, 0.8)',
                    'rgba(255, 205, 86, 0.8)'
                ],
                borderColor: 'rgba(255, 255, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: { color: 'rgba(255, 255, 255, 0.8)' }
                }
            }
        }
    });
</script>

</body>
</html>
